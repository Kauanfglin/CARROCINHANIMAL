<?php
include('includes/conexao.php');

if (isset($_GET['id'])) {
    $id_animal = $_GET['id'];

    $sql = "SELECT * FROM Animal WHERE id_animal = ?";
    $stmt = mysqli_prepare($con, $sql);

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "i", $id_animal);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if (mysqli_num_rows($result) == 1) {
            $row = mysqli_fetch_assoc($result);
        } else {
            echo "Animal não encontrado.";
            exit; 
        }

        mysqli_stmt_close($stmt);
    } else {
        echo "Erro ao preparar a consulta: " . mysqli_error($con);
        exit; 
    }
} else {
    echo "ID do animal não especificado.";
    exit; 
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alteração de Animal</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 20px;
            background-color: #f0f0f0;
        }
        form {
            max-width: 600px;
            margin: auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        fieldset {
            border: 1px solid #ccc;
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 5px;
        }
        legend {
            font-size: 1.2em;
            margin-bottom: 10px;
        }
        label {
            display: block;
            margin-bottom: 8px;
        }
        input[type="text"], input[type="date"], input[type="number"], select {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 3px;
            box-sizing: border-box;
            font-size: 1em;
        }
        button[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 3px;
            cursor: pointer;
            font-size: 1em;
        }
        button[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <form action="alteraAnimalExe.php" method="post">
        <fieldset>
            <legend>Alteração de Animal</legend>
            <input type="hidden" name="id_animal" value="<?php echo htmlspecialchars($row['id_animal']); ?>">
            <div>
                <label for="nome">Nome:</label>
                <input type="text" name="nome" id="nome" value="<?php echo htmlspecialchars($row['nome']); ?>" required>
            </div>
            <div>
                <label for="especie">Espécie:</label>
                <input type="text" name="especie" id="especie" value="<?php echo htmlspecialchars($row['especie']); ?>" required>
            </div>
            <div>
                <label for="raca">Raça:</label>
                <input type="text" name="raca" id="raca" value="<?php echo htmlspecialchars($row['raca']); ?>" required>
            </div>
            <div>
                <label for="data_nasc">Data de Nascimento:</label>
                <input type="date" name="data_nasc" id="data_nasc" value="<?php echo htmlspecialchars($row['data_nasc']); ?>" required>
            </div>
            <div>
                <label for="idade">Idade:</label>
                <input type="number" name="idade" id="idade" value="<?php echo htmlspecialchars($row['idade']); ?>" required>
            </div>
            <div>
                <label for="castrado">Castrado:</label>
                <select name="castrado" id="castrado" required>
                    <option value="1" <?php echo ($row['castrado'] == '1') ? 'selected' : ''; ?>>Sim</option>
                    <option value="0" <?php echo ($row['castrado'] == '0') ? 'selected' : ''; ?>>Não</option>
                </select>
            </div>
            <div>
                <label for="id_pessoa">Proprietário:</label>
                <select name="id_pessoa" id="id_pessoa" required>
                    <?php
                    $sql_pessoa = "SELECT id_pessoa, nome FROM Pessoa";
                    $result_pessoa = mysqli_query($con, $sql_pessoa);

                    if ($result_pessoa) {
                        while ($pessoa = mysqli_fetch_assoc($result_pessoa)) {
                            $selected = ($pessoa['id_pessoa'] == $row['id_pessoa']) ? 'selected' : '';
                            echo "<option value='".$pessoa['id_pessoa']."' $selected>".$pessoa['nome']."</option>";
                        }
                    } else {
                        echo "<option value=''>Erro ao carregar proprietários</option>";
                    }
                    ?>
                </select>
            </div>
            <div style="text-align: center;">
                <button type="submit">Salvar Alterações</button>
            </div>
        </fieldset>    
    </form>
</body>
</html>
