<?php
include('includes/conexao.php');

if ($con === false) {
    die("Erro de conexão: " . mysqli_connect_error());
}

if (isset($_GET['id'])) {
    $id_animal = mysqli_real_escape_string($con, $_GET['id']);

    if (is_numeric($id_animal)) {
        $sql = "DELETE FROM Animal WHERE id_animal = ?";
        $stmt = mysqli_prepare($con, $sql);

        if ($stmt) {
            mysqli_stmt_bind_param($stmt, "i", $id_animal);
            $result = mysqli_stmt_execute($stmt);

            if ($result) {
                echo "<h2>Animal excluído com sucesso!</h2>";
                echo "<p><a href='consultaAnimais.php'>Voltar para a consulta de animais</a></p>";
            } else {
                echo "<h2>Erro ao excluir o animal</h2>";
                echo "<p>" . mysqli_error($con) . "</p>";
            }

            mysqli_stmt_close($stmt);
        } else {
            echo "<h2>Erro ao preparar a consulta</h2>";
            echo "<p>" . mysqli_error($con) . "</p>";
        }
    } else {
        echo "<h2>ID inválido</h2>";
    }
} else {
    echo "<h2>ID do animal não especificado</h2>";
}

mysqli_close($con);
?>
