<?php
include('includes/conexao.php');

if ($con === false) {
    die("Erro de conexão: " . mysqli_connect_error());
}

if (isset($_GET['id'])) {
    $id = mysqli_real_escape_string($con, $_GET['id']);

    $sql = "DELETE FROM Cidade WHERE id = ?";
    $stmt = mysqli_prepare($con, $sql);

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "i", $id);
        $result = mysqli_stmt_execute($stmt);

        if ($result) {
            echo "<h2>Cidade excluída com sucesso!</h2>";
            echo "<p><a href='consultaCidades.php'>Voltar para a lista de cidades</a></p>";
        } else {
            echo "<h2>Erro ao excluir a cidade</h2>";
            echo "<p>" . mysqli_error($con) . "</p>";
        }

        mysqli_stmt_close($stmt);
    } else {
        echo "<h2>Erro ao preparar a consulta</h2>";
        echo "<p>" . mysqli_error($con) . "</p>";
    }

    mysqli_close($con);
} else {
    echo "<h2>ID da cidade não especificado.</h2>";
}
?>
