<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    include('includes/conexao.php');

    if (!$con) {
        die("ERROR: Não foi possível conectar ao banco de dados. " . mysqli_connect_error());
    }

    $nome = mysqli_real_escape_string($con, $_POST['nome']);
    $email = mysqli_real_escape_string($con, $_POST['email']);
    $senha = mysqli_real_escape_string($con, $_POST['senha']); 

    $sql_cliente = "INSERT INTO Cliente (nome, email, senha) VALUES (?, ?, ?)";
    $stmt_cliente = mysqli_prepare($con, $sql_cliente);
    mysqli_stmt_bind_param($stmt_cliente, "sss", $nome, $email, $senha);

    if (mysqli_stmt_execute($stmt_cliente)) {
        echo "<h2>Cliente cadastrado com sucesso!</h2>";
    } else {
        echo "<h2>Erro ao cadastrar cliente</h2>";
        echo mysqli_error($con);
    }

    mysqli_stmt_close($stmt_cliente);
    mysqli_close($con);
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Cliente</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 20px;
            background-color: #f0f0f0;
        }
        form {
            max-width: 500px;
            margin: auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        fieldset {
            border: 1px solid #ccc;
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 5px;
        }
        legend {
            font-size: 1.2em;
            margin-bottom: 10px;
        }
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }
        input[type="text"], input[type="email"], input[type="password"] {
            width: calc(100% - 22px);
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 3px;
            box-sizing: border-box;
            font-size: 1em;
            margin-bottom: 10px;
        }
        button[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 3px;
            cursor: pointer;
            font-size: 1em;
            transition: background-color 0.3s;
        }
        button[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <h3>Formulário de Cadastro de Cliente</h3>
    <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
        <fieldset>
            <legend>Cadastro de Cliente</legend>

            <label for="nome">Nome:</label>
            <input type="text" id="nome" name="nome" required><br>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required><br>

            <label for="senha">Senha:</label>
            <input type="password" id="senha" name="senha" required><br>

            <button type="submit">Cadastrar</button>
        </fieldset>
    </form>
</body>
</html>
