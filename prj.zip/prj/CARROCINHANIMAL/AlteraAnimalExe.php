<?php
include('includes/conexao.php');

if ($con === false) {
    die("Erro de conexão: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_animal = mysqli_real_escape_string($con, $_POST['id_animal']);
    $nome = mysqli_real_escape_string($con, $_POST['nome']);
    $especie = mysqli_real_escape_string($con, $_POST['especie']);
    $raca = mysqli_real_escape_string($con, $_POST['raca']);
    $data_nasc = mysqli_real_escape_string($con, $_POST['data_nasc']);
    $idade = mysqli_real_escape_string($con, $_POST['idade']);
    $castrado = mysqli_real_escape_string($con, $_POST['castrado']);
    $id_pessoa = mysqli_real_escape_string($con, $_POST['id_pessoa']);

    $sql = "UPDATE Animal SET nome = ?, especie = ?, raca = ?, data_nasc = ?, idade = ?, castrado = ?, id_pessoa = ? WHERE id_animal = ?";
    $stmt = mysqli_prepare($con, $sql);

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "ssssiiii", $nome, $especie, $raca, $data_nasc, $idade, $castrado, $id_pessoa, $id_animal);
        $result = mysqli_stmt_execute($stmt);

        if ($result) {
            echo "<h2>Animal atualizado com sucesso!</h2>";
            echo "<p><a href='consultaAnimais.php'>Voltar para a consulta de animais</a></p>";
        } else {
            echo "<h2>Erro ao atualizar o animal</h2>";
            echo "<p>" . mysqli_error($con) . "</p>";
        }

        mysqli_stmt_close($stmt);
    } else {
        echo "<h2>Erro ao preparar a consulta</h2>";
        echo "<p>" . mysqli_error($con) . "</p>";
    }

    mysqli_close($con);
}
?>
