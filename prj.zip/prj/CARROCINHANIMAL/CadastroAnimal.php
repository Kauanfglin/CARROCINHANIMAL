<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    include('includes/conexao.php');

    if ($con === false) {
        die("ERROR: Could not connect. " . mysqli_connect_error());
    }

    $nome = mysqli_real_escape_string($con, $_POST['nome']);
    $especie = mysqli_real_escape_string($con, $_POST['especie']);
    $raca = mysqli_real_escape_string($con, $_POST['raca']);
    $data_nasc = mysqli_real_escape_string($con, $_POST['data_nasc']);
    $idade = intval($_POST['idade']);
    $id_pessoa = intval($_POST['proprietario']); 
    $castrado = intval($_POST['castrado']); 

    $sql_animal = "INSERT INTO Animal (nome, especie, raca, data_nasc, idade, id_pessoa, castrado) 
                   VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt_animal = mysqli_prepare($con, $sql_animal);

    if ($stmt_animal === false) {
        die("ERROR: Could not prepare the statement. " . mysqli_error($con));
    }

    mysqli_stmt_bind_param($stmt_animal, "ssssiii", $nome, $especie, $raca, $data_nasc, $idade, $id_pessoa, $castrado);

    if (mysqli_stmt_execute($stmt_animal)) {
        echo "<h2>Dados do animal cadastrados com sucesso</h2>";
    } else {
        echo "<h2>Erro ao cadastrar animal</h2>";
        echo mysqli_stmt_error($stmt_animal);
    }

    mysqli_stmt_close($stmt_animal);
    mysqli_close($con);
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Animal</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 20px;
            background-color: #f0f0f0;
        }
        h1, h3 {
            text-align: center;
            margin-bottom: 20px;
        }
        form {
            max-width: 800px;
            margin: auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        fieldset {
            border: 1px solid #ccc;
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 5px;
        }
        legend {
            font-size: 1.2em;
            margin-bottom: 10px;
            background-color: #007bff;
            color: #fff;
            padding: 10px;
            border-radius: 5px;
        }
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }
        input[type="text"], input[type="date"], select {
            width: calc(100% - 22px); 
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 3px;
            box-sizing: border-box;
            font-size: 1em;
            margin-bottom: 10px;
        }
        button[type="submit"] {
            background-color: #007bff;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 3px;
            cursor: pointer;
            font-size: 1em;
            transition: background-color 0.3s;
            display: block;
            width: 100%;
        }
        button[type="submit"]:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
<form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
    <label for="nome">Nome:</label>
    <input type="text" id="nome" name="nome" required><br>

    <label for="especie">Espécie:</label>
    <input type="text" id="especie" name="especie" required><br>

    <label for="raca">Raça:</label>
    <input type="text" id="raca" name="raca" required><br>

    <label for="data_nasc">Data de Nascimento:</label>
    <input type="date" id="data_nasc" name="data_nasc" required><br>

    <label for="idade">Idade:</label>
    <input type="text" id="idade" name="idade" required><br>

    <label for="proprietario">Proprietário:</label>
    <select id="proprietario" name="proprietario" required>
        <?php
        include('includes/conexao.php');

        $sql_proprietarios = "SELECT id_pessoa, nome FROM Pessoa";
        $result_proprietarios = mysqli_query($con, $sql_proprietarios);

        if (mysqli_num_rows($result_proprietarios) > 0) {
            while ($row = mysqli_fetch_assoc($result_proprietarios)) {
                echo "<option value='" . $row['id_pessoa'] . "'>" . $row['nome'] . "</option>";
            }
        } else {
            echo "<option value=''>Nenhum proprietário encontrado</option>";
        }

        mysqli_close($con);
        ?>
    </select><br>

    <label for="castrado">Castrado:</label>
    <select id="castrado" name="castrado" required>
        <option value="1">Sim</option>
        <option value="0">Não</option>
    </select><br>

    <button type="submit">Cadastrar</button>
</form>
</body>
</html>
