<?php
include('includes/conexao.php');

if ($con === false) {
    die("Erro de conexão: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = mysqli_real_escape_string($con, $_POST['id']);
    $nome = mysqli_real_escape_string($con, $_POST['nome']);
    $estado = mysqli_real_escape_string($con, $_POST['estado']);

    $sql = "UPDATE Cidade SET nome = ?, estado = ? WHERE id = ?";
    $stmt = mysqli_prepare($con, $sql);

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "ssi", $nome, $estado, $id);
        $result = mysqli_stmt_execute($stmt);

        if ($result) {
            echo "<h2>Cidade atualizada com sucesso!</h2>";
            echo "<p><a href='consultaCidades.php'>Voltar para a consulta de cidades</a></p>";
        } else {
            echo "<h2>Erro ao atualizar a cidade</h2>";
            echo "<p>" . mysqli_error($con) . "</p>";
        }

        mysqli_stmt_close($stmt);
    } else {
        echo "<h2>Erro ao preparar a consulta</h2>";
        echo "<p>" . mysqli_error($con) . "</p>";
    }

    mysqli_close($con);
}
?>
