<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Cidades</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 20px;
            background-color: #f0f0f0;
        }
        form {
            max-width: 400px;
            margin: auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        fieldset {
            border: 1px solid #ccc;
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 5px;
        }
        legend {
            font-size: 1.2em;
            margin-bottom: 10px;
        }
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }
        input[type="text"], select {
            width: calc(100% - 18px); 
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 3px;
            box-sizing: border-box;
            font-size: 1em;
            margin-bottom: 10px;
        }
        button[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 3px;
            cursor: pointer;
            font-size: 1em;
            transition: background-color 0.3s;
        }
        button[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <fieldset>
            <legend>Cadastro de Cidades</legend>
            <div>
                <label for="nome">Nome:</label>
                <input type="text" name="nome" id="nome" required>
            </div>
            <div>
                <label for="estado">Estado:</label>
                <select name="estado" id="estado" required>
                    <option value="SP">SP</option>
                    <option value="RJ">RJ</option>
                    <option value="MG">MG</option>
                </select>
            </div>
            <div style="text-align: center;">
                <button type="submit">Cadastrar</button>
            </div>
        </fieldset>    
    </form>
</body>
</html>

<?php
include('includes/conexao.php');

if (!$con) {
    die("Conexão falhou: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = mysqli_real_escape_string($con, $_POST['nome']);
    $estado = mysqli_real_escape_string($con, $_POST['estado']);

    $sql = "INSERT INTO cidade (nome, estado) VALUES (?, ?)";
    $stmt = mysqli_prepare($con, $sql);

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "ss", $nome, $estado);
        $result = mysqli_stmt_execute($stmt);

        if ($result) {
            echo "<h2>Cidade cadastrada com sucesso!</h2>";
            echo "<p>Nome: $nome</p>";
            echo "<p>Estado: $estado</p>";
        } else {
            echo "<h2>Erro ao cadastrar cidade</h2>";
            echo "<p>" . mysqli_error($con) . "</p>";
        }

        mysqli_stmt_close($stmt);
    } else {
        echo "<h2>Erro ao preparar a consulta</h2>";
        echo "<p>" . mysqli_error($con) . "</p>";
    }

    mysqli_close($con);
}
?>
