<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consulta de Animais</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 20px;
            background-color: #f0f0f0;
        }
        h1 {
            text-align: center;
            margin-bottom: 20px;
        }
        table {
            width: 80%;
            margin: 0 auto;
            border-collapse: collapse;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        th, td {
            padding: 10px;
            text-align: center;
            border: 1px solid #ccc;
        }
        th {
            background-color: #007bff;
            color: #fff;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        a {
            text-decoration: none;
            color: #007bff;
            cursor: pointer;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <h1>Consulta de Animais</h1>
    <table>
        <tr>
            <th>ID</th>
            <th>Nome</th>
            <th>Espécie</th>
            <th>Raça</th>
            <th>Data de Nascimento</th>
            <th>Idade</th>
            <th>Castrado</th>
            <th>Proprietário</th>
            <th>Alterar</th>
            <th>Excluir</th>
        </tr>
        <?php
        include('includes/conexao.php');

        if ($con === false) {
            die("Erro de conexão: " . mysqli_connect_error());
        }

        $sql = "SELECT a.id_animal, a.nome, a.especie, a.raca, a.data_nasc, a.idade, 
                       CASE 
                           WHEN a.castrado = 1 THEN 'Sim'
                           ELSE 'Não'
                       END AS castrado,
                       CONCAT(p.nome, ' ', p.email) AS proprietario
                FROM Animal a
                INNER JOIN Pessoa p ON a.id_pessoa = p.id_pessoa";

        $result = mysqli_query($con, $sql);

        if ($result) {
            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>";
                    echo "<td>".$row['id_animal']."</td>";
                    echo "<td>".$row['nome']."</td>";
                    echo "<td>".$row['especie']."</td>";
                    echo "<td>".$row['raca']."</td>";
                    echo "<td>".$row['data_nasc']."</td>";
                    echo "<td>".$row['idade']."</td>";
                    echo "<td>".$row['castrado']."</td>";
                    echo "<td>".$row['proprietario']."</td>";
                    echo "<td><a href='alteranimal.php?id=".$row['id_animal']."'>Alterar</a></td>";
                    echo "<td><a href='ExcluiAnimal.php?id=".$row['id_animal']."'>Excluir</a></td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='10'>Nenhum animal cadastrado.</td></tr>";
            }
        } else {
            echo "<tr><td colspan='10'>Erro na consulta SQL: " . mysqli_error($con) . "</td></tr>";
        }

        mysqli_close($con);
        ?>
    </table>
</body>
</html>
